from db_helper import Student
# создать объект базы данных
database_students = Student()
# логика
# добавление записи


def add_command(number, vehicle_type, place, speed):
 database_students.insert(number, vehicle_type, place, speed)
# просмотр всех записей


def view_command():
 for row in database_students.view():
    print(row)
# основная программа в консоли
# добавление записи
for i in range(5):
 add_command(int(input("Введите номер: ")),
 input("Введите тип: "),
 int(input("Введите кол-во мест: ")),
 int(input("Введите скорость: ")))
# просмотр всех записей
view_command()
