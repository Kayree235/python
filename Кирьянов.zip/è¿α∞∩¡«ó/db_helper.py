import sqlite3
# создание класса БД

class Student:
 # конструктор класса
 def __init__(self):
   self.con = sqlite3.connect("students.db")
   self.cur = self.con.cursor()
   self.cur.execute(
    "CREATE TABLE IF NOT EXISTS airr "
    "(ID INTEGER PRIMARY KEY,"
    "number TEXT,"
    "vehicle_type TEXT,"
    "place TEXT,"
    "speed TEXT)"
   )
   self.con.commit()
  # сохранить изменения
   self.con.commit()


 def __del__(self):
  # отключение от БД
  self.con.close()


 def view(self):
 # просмотр всех записей в таблице БД
  self.cur.execute("SELECT * FROM airr")
 # список всех записей из таблицы
  rows = self.cur.fetchall()
  return rows


 def insert(self, number, vehicle_type, place, speed):
 # добавить запись
  self.cur.execute("INSERT INTO airr "
                   "VALUES (NULL, ?, ?, ?, ?)", (number, vehicle_type, place, speed,))
  self.con.commit()


 def update(self, id, number, vehicle_type, place, speed):
  # редактирование записи
  self.cur.execute("UPDATE airr SET "
                   "number=?, vehicle_type=?, place=?, speed=?", (number, vehicle_type, place, speed,))
  self.con.commit()

 def delete(self, id):
  self.cur.execute("DELETE FROM airr "
                   "WHERE ID=?", (id,))
  self.con.commit()


 def search(self, number):
   self.cur.execute("SELECT vehicle_type, place, speed FROM airr "
                    "WHERE number=?", (number,))
   rows = self.cur.fetchall()
   return rows