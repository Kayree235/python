from db_helper import Student
# создать объект базы данных
database_students = Student()
# удаление по id самолета


def update_command(id, number, vehicle_type, place, speed):
 database_students.update(id, number, vehicle_type, place, speed)
 print(f"Данные самолета с id = {id} обновлены")
# просмотр всех записей


def view_command():
 for row in database_students.view():
    print(row)
# основная программа
print("Список самолетов")
view_command()
id_update = int(input("Введите id самолета "))
print("Укажите новые данные: ")
number = input("Номер: ")
vehicle_type = input("Тип: ")
place = float(input("Кол-во мест: "))
speed = input("Скорость: ")
update_command(id_update, number, vehicle_type, place, speed)
print("Список самолетов")
view_command()